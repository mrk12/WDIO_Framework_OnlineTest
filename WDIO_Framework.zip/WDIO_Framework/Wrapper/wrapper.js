const CommonPage = require("./../pages/CommonPage.js");
const CommonData = require("./../Locators/CommonLocators.json")
const EC = require('wdio-wait-for');

const allureReport = require('@wdio/allure-reporter').default
class Wrapper {
    /** 
     * Below function is to navigate to the specific URL in web page 
     *@param1 : URL of the page 
    */

    async goto(URL) {
        await browser.url(URL);
    }

    async Launch(relationShipId, relationShipName) {
        let URL
        if (global.Environment === "QA")
            URL = "https://www.google.com";
        else
            URL = "https://www.google.com";
        await this.goto(URL);
        await this.Wait(20000);
    }
   
    /** Below function is to verify inner Text to the specific element in web page 
    * @param1 : Locator of the element 
    * @param2 : expected Text and it will return assertion
    */
    async verifyText(Locator, expectedText, description, Type) {
        let actualText;
        const elem = await $(Locator);
        if (Type === "value")
            actualText = await elem.getValue();
        else
            actualText = await elem.getText();
        await this.expectWithReporting(description, expectedText, actualText)
    }

    /** Below function is to Enter the text into the input box 
    * @param1 : input box locator 
    * @param2 : Text to Enter 
    */
    async enterText(Locator, inputText) {
        await this.WaitForElementToPresent(Locator);
        await $(Locator).click();//setValue(inputText);
        await $(Locator).setValue(inputText)
    }
    /** Below function is to click element
    * @param1 : element locator 
    */
    async clickButton(Locator) {
        const myButton = await $(Locator)
        // await myButton.touchAction('tap'); press or hover
        await myButton.click()
    }
    /** Below function is to validate the page URL 
    * @param1 : expected URL of the page 
    */

    async verifyPageURL(URL) {
        await browser.waitUntil(
            async () => (await browser.getUrl()) === URL,
            {
                timeout: 50000,
                timeoutMsg: 'expected text to be different after 50 s'
            }
        );
    }
   
    async expectWithReporting(description, expectedText, actualText) {
        // allure.addDescription(description)
        // const image = await browser.takeScreenshot();
        if (expectedText === actualText) {
            allureReport.startStep(`${description}`)
            allureReport.addStep("expect '" + expectedText + "' toBe '" + actualText + "'");
            allureReport.endStep("passed");
           // browser.takeScreenshot();
        }
        else {
            allureReport.startStep(`${description}`)
            allureReport.addStep("expect '" + expectedText + "' toBe '" + actualText + "'", "", "failed");
            allureReport.endStep("failed");
            browser.takeScreenshot();
        }
        expect(expectedText).toBe(actualText)
    }
    async expectWithReportingToEqual(description, expectedText, actualText) {
        // allure.addDescription(description)
        // const image = await browser.takeScreenshot();
        if (expectedText === actualText) {
            allureReport.startStep(`${description}`)
            allureReport.addStep("expect '" + expectedText + "' toEqual '" + actualText + "'");
            allureReport.endStep("passed");
        }
        else {
            allureReport.startStep(`${description}`)
            allureReport.addStep("expect '" + expectedText + "' toEqual '" + actualText + "'", "", "failed");
            allureReport.endStep("failed");
            browser.takeScreenshot();
        }
        expect(expectedText).toEqual(actualText)
    }
    /** 
     * Below function is to load Initial page load 
     *@param {String}  eleLocator -- element xpath or CSS Selector  
    */
    async WaitForElementToPresent(eleLocator) {
        const elem = await $(eleLocator)
        await this.WaitTillLoaderdisappers();
        await elem.waitForExist({
            timeout: CommonData.waitTime,
            timeoutMsg: 'expected selector ' + eleLocator + ' not loaded after ' + CommonData.waitTime
        });
    }
    /** 
     * Below function is to load Initial page load 
     *@param {String}  eleLocator -- element xpath or CSS Selector  
    */
    async WaitForElementToDisplayed(eleLocator) {
        const elem = await $(eleLocator)
        await elem.waitForDisplayed({
            timeout: CommonData.waitTime,
            timeoutMsg: 'expected selector ' + eleLocator + ' not displayed after ' + CommonData.waitTime
        });
    }
    async waitUntilURLLoads(URLEndsWIthText) {
        await browser.waitUntil(async () => {
            return (await browser.getUrl()).endsWith(URLEndsWIthText);
        }, {
            timeout: 20000,
            timeoutMsg: `URL ending with ${URLEndsWIthText} not found`,
        });
    }

    /**
     * Check if the given element exists in the DOM one or more times
     * @param  {String}  selector  Element selector
     * @param  {Boolean} falseCase Check if the element (does not) exists
     * @param  {Number}  exactlyCount   Check if the element exists exactly this number
     *                             of times
    */
    async checkIfElementExists(selector, falseCase, exactlyCount) {
        const nrOfElements = await $$(selector);
        if (falseCase === true) {
            expect(nrOfElements).toBe(0);
        } else if (exactlyCount) {
            this.expectWithReportingInWrapper("Verify Elements length With locator " + selector, exactlyCount, nrOfElements.length)

        } else {
            this.expectWithReportingInWrapper("Verify Elements length With locator " + selector, 1, nrOfElements.length)
        }
    }
    /**
     * Check if the given elements text is the same as the given text
     * @param  {String}   selector      Element selector
     * @param  {String}   falseCase     Whether to check if the content equals the
     *                                  given text or not
     * @param  {String}   expectedText  The text to validate against
     */
    async checkEqualsText(selector, falseCase, expectedText) {
        let actualText = await $(selector).getText();
        actualText = actualText.replace(/\n/g, ' ');
        if (falseCase) {
            expect(expectedText).not.toBe(actualText);
        } else {
            this.expectWithReportingInWrapper("Verify " + expectedText, expectedText, actualText.trim())
        }
    }
    /** 
     * Below function is to wait for specific Time 
     *@param1 : Wait Time in milliSeconds  
    */
    async Wait(waitTime) {
        await browser.pause(waitTime);
    }
    
    async getAttributeText(Selector, attributeName) {
        const attributeValue = await $(Selector).getAttribute(attributeName)
        return attributeValue;
    }
   
    async SwitchToNewWindow(num) {
        await this.Wait(5000);
        const allGUIDs = await browser.getWindowHandles();
        await browser.switchToWindow(allGUIDs[num]);
    }
   
    async expectWithReportingInWrapper(description, expectedText, actualText) {
        if (expectedText === actualText) {
            allureReport.startStep(`${description}`)
            allureReport.addStep("expect '" + expectedText + "' toBe '" + actualText + "'");
            allureReport.endStep("passed");
        }
        else {
            allureReport.startStep(`${description}`)
            allureReport.addStep("expect '" + expectedText + "' toBe '" + actualText + "'", "", "failed");
            allureReport.endStep("failed");
            browser.takeScreenshot();
        }
        expect(expectedText).toBe(actualText)
    }
    async HandleWindowsPopup(user, pwd) {
        const exec = require('child_process');
        var process = require('process');
        process.chdir('..\\WindowsHandler');
        exec.execSync("alert.exe " + user, pwd);
    }
   
    // //Verify label text
    // async verifyLabelText(Xpath, Expected) {
    //     const label = await $(Xpath);
    //     const labelText = await label.getText();
    //     // expect(label).toHaveValue(Expected, { ignoreCase: false })
    //     await expect(labelText).to.equal(Expected);
    // }


       async verifylabelText(Xpath, ExpectedText){
              let myScope = this;
            //   browser.waitUntil(visibilityOf(Xpath));
            //   browser.wait(EC.visibilityOf(Xpath));
                    await expect(Xpath).toBePresent()
                    await $(Xpath).getText().then(function (text) {
                    const text1 = text.replace(/\n/g, " ");
                    myScope.expectWithReportingInWrapper(
                    "Verify '" + ExpectedText + "' Label Text",
                    text1.trim(),
                    ExpectedText
                  );
                //   myScope.TakeScreenShot;
                });
            }
    /**
     * 
     * @param {*} Selector 
     * @param {*} attributeName 
     * @param {*} expectedValue 
     */
    async VerifyCSSProperty(Selector, attributeName, expectedValue, component) {
        const CSSValue = await $(Selector).getCSSProperty(attributeName)
        this.expectWithReportingInWrapper("Verify " + component + " " + attributeName, expectedValue, CSSValue.value)
    }
    /**
     * 
     */
    async WaitTillLoaderdisappers() {
        await browser.waitUntil(async function () {
            const flag = await $("(//mat-progress-spinner)[1]").isExisting();
            return !flag
        }, 70000, "Still Page Loading");
    }

}
module.exports = new Wrapper();