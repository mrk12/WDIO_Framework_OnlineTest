const allureReport = require('@wdio/allure-reporter').default
const Wrapper = require("./../Wrapper/wrapper.js")
//const Obj = require("./../Locators/Accounts.json")
class CommonPage {
    async Launch(relationShipId, relationShipName) {
        let URL
        if (global.Environment === "QA")
            URL = "https://www.google.com";
        else
            URL = "https://www.google.com";
        await Wrapper.goto(URL);
        await Wrapper.Wait(20000);
    }
   
    /** Below function is to verify inner Text to the specific element in web page 
    * @param1 : Locator of the element 
    * @param2 : expected Text and it will return assertion
    */
    async verifyText(Locator, expectedText, description, Type) {
        let actualText;
        const elem = await $(Locator);
        if (Type === "value")
            actualText = await elem.getValue();
        else
            actualText = await elem.getText();
        await this.expectWithReporting(description, expectedText, actualText)
    }

    /** Below function is to Enter the text into the input box 
    * @param1 : input box locator 
    * @param2 : Text to Enter 
    */
    async enterText(Locator, inputText) {
        await Wrapper.WaitForElementToPresent(Locator);
        await $(Locator).click();//setValue(inputText);
        await $(Locator).setValue(inputText)
    }
    /** Below function is to click element
    * @param1 : element locator 
    */
    async clickButton(Locator) {
        const myButton = await $(Locator)
        // await myButton.touchAction('tap'); press or hover
        await myButton.click()
    }
    /** Below function is to validate the page URL 
    * @param1 : expected URL of the page 
    */

    async verifyPageURL(URL) {
        await browser.waitUntil(
            async () => (await browser.getUrl()) === URL,
            {
                timeout: 50000,
                timeoutMsg: 'expected text to be different after 50 s'
            }
        );
    }
   
    async expectWithReporting(description, expectedText, actualText) {
        // allure.addDescription(description)
        // const image = await browser.takeScreenshot();
        if (expectedText === actualText) {
            allureReport.startStep(`${description}`)
            allureReport.addStep("expect '" + expectedText + "' toBe '" + actualText + "'");
            allureReport.endStep("passed");
           // browser.takeScreenshot();
        }
        else {
            allureReport.startStep(`${description}`)
            allureReport.addStep("expect '" + expectedText + "' toBe '" + actualText + "'", "", "failed");
            allureReport.endStep("failed");
            browser.takeScreenshot();
        }
        expect(expectedText).toBe(actualText)
    }
    async expectWithReportingToEqual(description, expectedText, actualText) {
        // allure.addDescription(description)
        // const image = await browser.takeScreenshot();
        if (expectedText === actualText) {
            allureReport.startStep(`${description}`)
            allureReport.addStep("expect '" + expectedText + "' toEqual '" + actualText + "'");
            allureReport.endStep("passed");
        }
        else {
            allureReport.startStep(`${description}`)
            allureReport.addStep("expect '" + expectedText + "' toEqual '" + actualText + "'", "", "failed");
            allureReport.endStep("failed");
            browser.takeScreenshot();
        }
        expect(expectedText).toEqual(actualText)
    }
   
}
module.exports = new CommonPage();