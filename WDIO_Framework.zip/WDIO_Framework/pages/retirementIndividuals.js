const retireIndividualsData = require("./../Locators/retirementIndividuals.json");
const CommonPage  = require('./../pages/CommonPage.js');
const Wrapper = require("./../Wrapper/wrapper.js");


class retirementIndividuals{
 /** Below function is to verify UI components in Home page */
 async launchApplication(){
    await browser.url("https://www.securian.com/insights-tools/retirement-calculator.html")
    await Wrapper.WaitForElementToDisplayed(retireIndividualsData.preRetirementHeaderTxtXpath);
}

async validateAge(){
    await Wrapper.WaitForElementToDisplayed(retireIndividualsData.AgeHeaderXpath);
    await Wrapper.checkEqualsText(retireIndividualsData.AgeHeaderXpath,false,retireIndividualsData.Data.AgeTxt)
     await Wrapper.enterText(retireIndividualsData.currentAgeXpath, retireIndividualsData.Data.CurrentAge);
     await CommonPage.expectWithReporting("Entered the Age in Age field","Success","Success")
}

async validateRetireAge(){
    await Wrapper.WaitForElementToDisplayed(retireIndividualsData.retirementAgeXpath);
    await Wrapper.enterText(retireIndividualsData.retirementAgeXpath, retireIndividualsData.Data.RetirementAge);
    await CommonPage.expectWithReporting("validation for Retirement age","Success","Success")
}

async validateAnnualIncome(){
    await Wrapper.WaitForElementToDisplayed(retireIndividualsData.annualIncomeHeaderXpath);
    await Wrapper.checkEqualsText(retireIndividualsData.annualIncomeHeaderXpath,false,retireIndividualsData.Data.AnnualIncomeHeaderTxt)
    await Wrapper.enterText(retireIndividualsData.currentAnnualIncomeXpath, retireIndividualsData.Data.CurrentAnnualIncome);
    await CommonPage.expectWithReporting("validate current annual income","Success","Success")
}
async validateSpouseAnnualIncome(){
    await Wrapper.WaitForElementToDisplayed(retireIndividualsData.spouseAnnualIncomeXpath);
     await Wrapper.enterText(retireIndividualsData.spouseAnnualIncomeXpath, retireIndividualsData.Data.SpouseAnnualIncome);
    await CommonPage.expectWithReporting("validate Spouse's annual income","Success","Success")
}

async validateCurrentRetirementSavings(){
    await Wrapper.WaitForElementToDisplayed(retireIndividualsData.currentRetirementSavingsXpath);
     await Wrapper.enterText(retireIndividualsData.currentRetirementSavingsXpath, retireIndividualsData.Data.CurrentRetirementSavings);
    await CommonPage.expectWithReporting("validate current retirement savings balance","Success","Success")
}
async validateCurrentRetirementSavingsEachYear(){
    await Wrapper.enterText(retireIndividualsData.currentlySavingYearXpath, retireIndividualsData.Data.CurrentRetirementContribution);
    await CommonPage.expectWithReporting("validate currently saving each year for retirement","Success","Success")
}
async validateRateIncreaseEachYear(){
    await Wrapper.enterText(retireIndividualsData.rateIncreaseEachYearXpath, retireIndividualsData.Data.AnnualRetirementContributionIncrease);
    await CommonPage.expectWithReporting("validate currently saving each year for retirement","Success","Success")
}

async clickOnCalculateBtn(){   
    await CommonPage.clickButton(retireIndividualsData.calculateBtnXpath)
}
async validatePreretirementHeader(){
    await Wrapper.WaitForElementToDisplayed(retireIndividualsData.preRetirementHeaderXpath);
     await Wrapper.checkEqualsText(retireIndividualsData.preRetirementHeaderXpath,false,retireIndividualsData.Data.PreRetirementCalculatorTxt);
}
async validateresults(){
    await Wrapper.WaitForElementToDisplayed(retireIndividualsData.resultsXpath);
    const resultsText = await $(retireIndividualsData.resultsXpath).getText()
    await console.log(resultsText)
    await Wrapper.checkEqualsText(retireIndividualsData.resultsXpath,false,retireIndividualsData.Data.ResultsTxt);
}

}

module.exports = new retirementIndividuals();