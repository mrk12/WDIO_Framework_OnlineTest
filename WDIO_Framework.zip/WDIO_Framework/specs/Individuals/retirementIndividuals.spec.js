const CommonPage = require("../../pages/CommonPage.js");
const retireIndividualsData = require("./../../Locators/retirementIndividuals.json");
const retirementIndividualsPage = require("../../pages/retirementIndividuals.js");
const Wrapper = require('../../Wrapper/wrapper');


describe("Verify Individuals retirement Plan, Basic Functionality", function () {

    it("Launch the Securian Application",async() =>{
        await retirementIndividualsPage.launchApplication();
    });
    it("Verify Age header and Enter the Age",async() =>{
        await retirementIndividualsPage.validateAge();
    });
    it("Enter the Retirement Age",async() =>{
        await retirementIndividualsPage.validateRetireAge();
    });
    it("Verify Anual income header and enter the annual income amount",async() =>{
        await retirementIndividualsPage.validateAnnualIncome();
    });
    it("Enter the Spouse's annual income amount",async() =>{
        await retirementIndividualsPage.validateSpouseAnnualIncome();
    });
    it("Enter the Current retirement savings balance",async() =>{
        await retirementIndividualsPage.validateCurrentRetirementSavings();
    });
    it("Enter the currently saving each year for retirement",async() =>{
        await retirementIndividualsPage.validateCurrentRetirementSavingsEachYear();
    });
    it("Enter the rate of increase in your savings each year",async() =>{
        await retirementIndividualsPage.validateRateIncreaseEachYear();
    });

    it("Click on Calculator button",async() =>{
        await retirementIndividualsPage.clickOnCalculateBtn();
    });
    it("Validate Pre-retirement calculator header",async() =>{
        await retirementIndividualsPage.validatePreretirementHeader();
    });

    it("Validate Results Amount",async() =>{
        await retirementIndividualsPage.validateresults();
    });
    
})