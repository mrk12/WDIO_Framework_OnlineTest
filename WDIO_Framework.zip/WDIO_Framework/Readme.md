# Author Swamy Kommu
# Initial Setup of Project 
1. If you're in the root directory of an existing project, run:
    **npm init wdio .**
2. Wait to install @wdio/CLI and answer the following questions
    1. On my local machine > Click Enter.
    2. Which framework do you want to use? (Use arrow keys) > Select Jasmine And Click Enter
    3. Do you want to use a compiler? (Use arrow keys) > No for JavaScript
    4. Where are your test specs located? (./test/specs/**/*.js) > Mention Project location or click enter for default location.
    5. Do you want WebdriverIO to autogenerate some test files?(Y/N) > Enter Y and click Enter, it will generate sample spec files.
    6. Do you want to use page objects (https://martinfowler.com/bliki/PageObject.html)? (Y/n) > Enter Y and click Enter, it will       generate sample Page files.
    7. Where are your page objects located? (./test/pageobjects/**/*.js) > Mention Pages location or click enter for default location.
    8. Which reporter do you want to use? (Press <space> to select, <a> to toggle all, <i> to invert selection, and <enter>
    to proceed) > Select Allure and click Enter
    9. Do you want to add a plugin to your test setup? (Press <space> to select, <a> to toggle all, <i> to invert selection,
    and <enter> to proceed) > Select Wait-for and click Enter.
    10. Do you want to add a service to your test setup? (Press <space> to select, <a> to toggle all, <i> to invert selection,
    and <enter> to proceed) > Select Chrome Service and click Enter
    11. What is the base url? (http://localhost) > Click Enter.
    12. Do you want me to run `npm install` (Y/n) > Press Y and click Enter (it will install all the dependencies).
# Push Code to BitBucket
1. Run git init in the terminal. This will initialize the folder/repository that you have on your local computer system.
2. Run git add . in the terminal. This will track any changes made to the folder on your system, since the last commit. As this is the first time you are committing the contents of the folder, it will add everything.
3. Run git commit -m"insert Message here". This will prepare the added/tracked changes to the folder on your system for pushing to Github. Here, insert Message here can be replaced with any relevant commit message of your choice.
4. Run git remote add origin https://github.com/Usheninte/example.git in the terminal. Here, Usheninte and example will be replaced by the values provided in the copied link. This will push the existing folder on you local computer system, to the newly created Github repository.
5. Run git remote -v. This does some git pull and git push magic, to ensure that the contents of your new Github repository, and the folder on you local system are the same.
6. Run git push origin master. Note that the last word in the command master, is not a fixed entry when running git push. It can be replaced with any relevant “branch_name”.

# How to Clone Project
1. Open Git Bash or Command Prompt at folder location.
2. Run command **git clone http://stash.noam.corp.frk.com:7990/scm/ftci/cmx-ui-automation.git**
3. Run **npm install** to install the required node modules (Which mentioned in Package.json)
#   HOW TO RUN SPEC FILE:
1. run the command in project location **npm run wdio**
2. If user wants run without package.json then excute below Command **npx wdio run wdio.conf.js --suite Test -ENV=UAT**
3. To run specific Spec File **npx wdio run ./wdio.conf.js --spec example.e2e.js**
